<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Watch Location</name>
   <tag></tag>
   <elementGuidId>f8b79ab9-d622-49cb-b723-0b63b0aca38d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.modal-body > div.form-group</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='frmWatchLocation']/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4ddecef1-6424-4c6c-9276-96d80402d54c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-group</value>
      <webElementGuid>50909abb-58ea-4177-a9f5-37b79f11b046</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Watch Location
            
            
        </value>
      <webElementGuid>de2cd9a7-df29-4ebf-a527-1c4dac388146</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;frmWatchLocation&quot;)/div[@class=&quot;modal-body&quot;]/div[@class=&quot;form-group&quot;]</value>
      <webElementGuid>e022b39e-b78b-4d4f-9b39-01f12bd39bd7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='frmWatchLocation']/div[2]/div</value>
      <webElementGuid>974d10c5-5558-49dd-b5ee-9671049ab123</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add Watch Location'])[1]/following::div[2]</value>
      <webElementGuid>14ecd161-2f54-4d4f-b776-28daaaca75e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Delete'])[1]/following::div[9]</value>
      <webElementGuid>41b9c37b-4aed-4fec-8730-bb571343a12e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notify Who'])[1]/preceding::div[1]</value>
      <webElementGuid>480ae14c-8c55-442b-86b9-9cfe4fbe89aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div[2]/div</value>
      <webElementGuid>7a91091e-7487-4bc1-9997-995d0326c790</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
            Watch Location
            
            
        ' or . = '
            Watch Location
            
            
        ')]</value>
      <webElementGuid>8fddea6a-eed8-4346-a7b0-e13708ee38ec</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
