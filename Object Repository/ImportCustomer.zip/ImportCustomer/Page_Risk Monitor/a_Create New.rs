<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Create New</name>
   <tag></tag>
   <elementGuidId>26042a64-5bab-4e54-8e0f-697663d66849</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='page-body-content']/div[3]/div/div/div[2]/p/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5678cdbe-51d5-40a7-912d-fdd1039e9abf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/Import/ImportCustomer/Create</value>
      <webElementGuid>8f7be794-ae96-47e8-9b50-ce91e318e2fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Create New</value>
      <webElementGuid>b9252493-97ab-4fde-8a19-c890489a6c8d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-body-content&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;card card-box&quot;]/div[@class=&quot;card-body&quot;]/p[1]/a[1]</value>
      <webElementGuid>362188f8-f844-4951-9726-50b857885630</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page-body-content']/div[3]/div/div/div[2]/p/a</value>
      <webElementGuid>abb08934-0734-4ac3-a605-6eeee3e61cf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Create New')]</value>
      <webElementGuid>e2ad2cee-f43a-4529-a43f-02064de3eae8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Environment Settings'])[1]/following::a[3]</value>
      <webElementGuid>55f68b5c-73d7-4ac0-bf05-34e95a9d46ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email Template'])[1]/following::a[4]</value>
      <webElementGuid>fdacaaff-4b27-422b-aafb-326ac3679c4c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit'])[1]/preceding::a[1]</value>
      <webElementGuid>81ce945f-e99c-4d5d-86eb-e24ac2815177</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Delete'])[1]/preceding::a[1]</value>
      <webElementGuid>21bb1d98-b372-4722-a076-2f503355479e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Create New']/parent::*</value>
      <webElementGuid>6fdb372f-f31d-420c-80eb-d1ad6e529bc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/Import/ImportCustomer/Create')]</value>
      <webElementGuid>7b6647c0-cffd-4192-b331-83f5d46ae680</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p/a</value>
      <webElementGuid>117d67f0-827e-4461-b5a0-68a394958367</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/Import/ImportCustomer/Create' and (text() = 'Create New' or . = 'Create New')]</value>
      <webElementGuid>0ad21c24-4c09-42b5-b4be-c81d1bcba277</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
